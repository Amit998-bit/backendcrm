const express = require("express");
const mongoose = require("mongoose");
const router = express.Router();
const User = require("../models/User");

// ✅ Register a New User
router.post("/register", async (req, res) => {
  try {
    const { name, email, password, role, parent } = req.body;

    // Ensure parent is either a valid ObjectId or null
    const parentId = parent && mongoose.Types.ObjectId.isValid(parent) ? parent : null;

    const newUser = new User({ name, email, password, role, parent: parentId });
    await newUser.save();

    res.json({ message: "User created successfully", user: newUser });
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(400).json({ message: "Error creating user", error: error.message });
  }
});

// ✅ Get All Users
router.get("/", async (req, res) => {
  try {
    const users = await User.find().populate("parent", "name email role");
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: "Error fetching users", error: error.message });
  }
});

// ✅ Get a Single User by ID
router.get("/:id", async (req, res) => {
  try {
    const user = await User.findById(req.params.id).populate("parent", "name email role");
    if (!user) return res.status(404).json({ message: "User not found" });
    
    res.json(user);
  } catch (error) {
    res.status(400).json({ message: "Invalid user ID", error: error.message });
  }
});

// ✅ Update a User by ID
router.put("/:id", async (req, res) => {
  try {
    const { name, email, password, role, parent } = req.body;

    // Ensure parent is either a valid ObjectId or null
    const parentId = parent && mongoose.Types.ObjectId.isValid(parent) ? parent : null;

    const updatedUser = await User.findByIdAndUpdate(
      req.params.id,
      { name, email, password, role, parent: parentId },
      { new: true, runValidators: true }
    );

    if (!updatedUser) return res.status(404).json({ message: "User not found" });

    res.json({ message: "User updated successfully", user: updatedUser });
  } catch (error) {
    res.status(400).json({ message: "Error updating user", error: error.message });
  }
});

// ✅ Delete a User by ID
router.delete("/:id", async (req, res) => {
  try {
    const deletedUser = await User.findByIdAndDelete(req.params.id);
    if (!deletedUser) return res.status(404).json({ message: "User not found" });

    res.json({ message: "User deleted successfully" });
  } catch (error) {
    res.status(400).json({ message: "Error deleting user", error: error.message });
  }
});

module.exports = router;
